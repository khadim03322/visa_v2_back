-- --------------------------------------------------------
-- Hôte:                         10.3.80.19
-- Version du serveur:           5.7.35-0ubuntu0.18.04.1 - (Ubuntu)
-- SE du serveur:                Linux
-- HeidiSQL Version:             11.1.0.6116
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Listage de la structure de la base pour bd_orbusLink_visa
CREATE DATABASE IF NOT EXISTS `bd_orbusLink_visa` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `bd_orbusLink_visa`;

-- Listage de la structure de la table bd_orbusLink_visa. td_contribuable
CREATE TABLE IF NOT EXISTS `td_contribuable` (
  `con_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `con_adresse_complete` varchar(255) DEFAULT NULL,
  `con_cofi` varchar(255) DEFAULT NULL,
  `con_ninea` varchar(255) DEFAULT NULL,
  `con_nom_ou_raison_social` varchar(255) DEFAULT NULL,
  `con_responsable_morale` varchar(255) DEFAULT NULL,
  `con_sigle` varchar(255) DEFAULT NULL,
  `con_telephone` varchar(255) DEFAULT NULL,
  `con_acp_id` bigint(20) DEFAULT NULL,
  `con_csf_id` bigint(20) DEFAULT NULL,
  `con_fon_id` bigint(20) DEFAULT NULL,
  `con_loc_id` bigint(20) DEFAULT NULL,
  `con_rei_id` bigint(20) DEFAULT NULL,
  `con_syc_id` bigint(20) DEFAULT NULL,
  `con_tye_id` bigint(20) DEFAULT NULL,
  `con_tys_id` bigint(20) DEFAULT NULL,
  `create_date_time` datetime DEFAULT NULL,
  `forme_juridique` tinyblob,
  `con_foj_id` bigint(20) DEFAULT NULL,
  `con_ass_id` bigint(20) DEFAULT NULL,
  `con_str_id` bigint(20) DEFAULT NULL,
  `con_abonnement` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`con_id`),
  UNIQUE KEY `UK_noflhcv3dyou75he8qevev4hp` (`con_ninea`),
  KEY `FKhqsoukw10latjaa8l8nd2jl0l` (`con_acp_id`),
  KEY `FKg2xxxt6aq96d9ktmqavcfh57i` (`con_csf_id`),
  KEY `FKo5oc6wvkmod9ggb0anvrtebj1` (`con_fon_id`),
  KEY `FK98w6icfem5rrsnil7g2nc7xge` (`con_loc_id`),
  KEY `FKe6tiopo6hbaar26qj3wfjrhhr` (`con_rei_id`),
  KEY `FKs3utwhkao3bgb5g0lcy7nps9m` (`con_syc_id`),
  KEY `FK4ov9udpt8cpl8s6rb136ukyyt` (`con_tye_id`),
  KEY `FKahlvdqv1qpg706jdpxqom5d08` (`con_tys_id`),
  KEY `FKiq9ahgpoqituxw2pr7hsgk8dg` (`con_ass_id`),
  KEY `FKey8muptpp3d73qbaoqih0nk57` (`con_str_id`),
  KEY `FKncmt8ty7xwwyifpdcdqk6ven` (`con_foj_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_contribuable : 11 rows
/*!40000 ALTER TABLE `td_contribuable` DISABLE KEYS */;
INSERT INTO `td_contribuable` (`con_id`, `con_adresse_complete`, `con_cofi`, `con_ninea`, `con_nom_ou_raison_social`, `con_responsable_morale`, `con_sigle`, `con_telephone`, `con_acp_id`, `con_csf_id`, `con_fon_id`, `con_loc_id`, `con_rei_id`, `con_syc_id`, `con_tye_id`, `con_tys_id`, `create_date_time`, `forme_juridique`, `con_foj_id`, `con_ass_id`, `con_str_id`, `con_abonnement`) VALUES
	(1, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '4H2', '000005951', 'SENBUS', 'Fatou BA', 'LNS', '', 3, 18, 2, 43, 1, 1, 2, 3, '2021-06-03 00:00:00', NULL, 3, NULL, 2, b'1'),
	(2, '1 ALLÉES SEYDOU NOUROU TALL ', '5G5', '000000018', 'SEN AUTO SA', 'Fatou BA', 'LNS', '', 2, 18, 2, 43, 3, 1, 1, 3, '2021-06-08 00:00:00', NULL, 3, NULL, 1, b'1'),
	(3, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '5G5', '000008484', 'ORBUS FACTORY SA', 'Mansour DIA', 'OFSA', '', 2, 18, 2, 45, 1, 1, 1, 1, '2021-06-09 00:00:00', NULL, 2, NULL, 3, b'0'),
	(4, '1 ALLÉES SEYDOU NOUROU TALL ', '4L5', '000340034', 'ORBUS GUCE', 'Fatou BA', 'AGC', '', 3, 17, 3, 45, 2, 1, 2, 3, '2021-06-09 00:00:00', NULL, 4, NULL, 3, b'1'),
	(5, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '4H2', '000345952', 'ORBUS DIGITAL SA', 'Assane DIOP', 'ODS', '', 3, 19, 2, 45, 1, 1, 2, 3, '2021-06-09 00:00:00', NULL, 3, NULL, 3, b'0'),
	(6, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '5G5', '000185951', 'SEN LOCATION', 'Asssane FALL', 'SLC', '', 2, 1, 3, 45, 3, 1, 2, 3, '2021-06-15 00:00:00', NULL, 4, NULL, 5, b'0'),
	(7, '1 ALLÉES SEYDOU NOUROU TALL DAKAR', '5G5', '000003418', 'TEXTILE DU SENEGAL', 'Fama DIOP', 'TSD', '', 7, 21, 4, 45, 2, 2, 2, 2, '2021-06-15 00:00:00', NULL, 4, NULL, 5, b'0'),
	(8, 'scat urbam', '1R1', '008340888', 'OBC', 'Racine', 'OBC', '', 5, 16, 4, 45, 1, 1, 2, 3, '2021-06-17 00:00:00', NULL, 10, NULL, 4, b'0'),
	(9, 'Point E', '2A2', '006241252', 'Racine INCO', 'Racine', 'RIC', '', 4, 18, 4, 45, 1, 1, 2, 1, '2021-06-28 00:00:00', NULL, 5, NULL, NULL, b'0'),
	(10, 'HLM ', '2A2', '002525626', 'CEA CABINET YOUSSOUPH BA', 'Mami Seyni', 'CCYB', '', 5, 18, 2, 45, 1, 1, 2, 2, '2021-06-28 00:00:00', NULL, 2, NULL, 4, b'0'),
	(11, 'Cité Alioune Sow en face PENTOLA allée hopital SAMU', '2A2', '000502767', 'CEC AFSA', 'DIOUMA', 'CEC', '', 4, 17, 1, 45, 1, 1, 1, 2, '2021-07-29 00:00:00', NULL, 10, NULL, 2, b'0');
/*!40000 ALTER TABLE `td_contribuable` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_contribuable_copie
CREATE TABLE IF NOT EXISTS `td_contribuable_copie` (
  `con_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `con_adresse_complete` varchar(255) DEFAULT NULL,
  `con_cofi` varchar(255) DEFAULT NULL,
  `con_ninea` varchar(255) DEFAULT NULL,
  `con_nom_ou_raison_social` varchar(255) DEFAULT NULL,
  `con_responsable_morale` varchar(255) DEFAULT NULL,
  `con_sigle` varchar(255) DEFAULT NULL,
  `con_telephone` varchar(255) DEFAULT NULL,
  `con_acp_id` bigint(20) DEFAULT NULL,
  `con_csf_id` bigint(20) DEFAULT NULL,
  `con_fon_id` bigint(20) DEFAULT NULL,
  `con_loc_id` bigint(20) DEFAULT NULL,
  `con_rei_id` bigint(20) DEFAULT NULL,
  `con_syc_id` bigint(20) DEFAULT NULL,
  `con_tye_id` bigint(20) DEFAULT NULL,
  `con_tys_id` bigint(20) DEFAULT NULL,
  `create_date_time` datetime DEFAULT NULL,
  `con_ass_id` bigint(20) DEFAULT NULL,
  `con_str_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`con_id`),
  KEY `FKf7eij2c10wv5436e36lcntt86` (`con_acp_id`),
  KEY `FK98rd6894mlfjh3i9v02rkvqx7` (`con_csf_id`),
  KEY `FKqmugcy8efwwf4kct72kqxbq4y` (`con_fon_id`),
  KEY `FK3iyyc64ggx6v55ce3wic1oshe` (`con_loc_id`),
  KEY `FKj4qgwp2htf9k73rdb47aurd5a` (`con_rei_id`),
  KEY `FK75t8ndrdimavpluli0u85jlgp` (`con_syc_id`),
  KEY `FKlbjxedm5182a8wg023mql48s3` (`con_tye_id`),
  KEY `FKl3gsfx17woifx38kknyyaxymg` (`con_tys_id`),
  KEY `FK3jhx0mtx0d30x31ce3535t5c` (`con_ass_id`),
  KEY `FKpcv5t9470xg8e9vnrau5coc24` (`con_str_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_contribuable_copie : 8 rows
/*!40000 ALTER TABLE `td_contribuable_copie` DISABLE KEYS */;
INSERT INTO `td_contribuable_copie` (`con_id`, `con_adresse_complete`, `con_cofi`, `con_ninea`, `con_nom_ou_raison_social`, `con_responsable_morale`, `con_sigle`, `con_telephone`, `con_acp_id`, `con_csf_id`, `con_fon_id`, `con_loc_id`, `con_rei_id`, `con_syc_id`, `con_tye_id`, `con_tys_id`, `create_date_time`, `con_ass_id`, `con_str_id`) VALUES
	(1, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '4H2', '000005951', 'SENBUS', 'Fatou BA', 'LNS', '', 3, 18, 2, 43, 1, 1, 2, 3, '2021-06-03 14:20:51', NULL, 2),
	(2, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '4H2', '000005951', 'SENBUS', 'Fatou BA', 'LNS', '', 3, 18, 2, 43, 1, 1, 2, 3, '2021-06-03 16:20:25', NULL, 2),
	(3, '1 ALLÉES SEYDOU NOUROU TALL DAKAR SENEGAL', '4H2', '000005951', 'SENBUS', 'Fatou BA', 'LNS', '', 3, 18, 2, 43, 1, 1, 2, 3, '2021-06-03 16:28:10', NULL, 2),
	(4, 'scat urbam', '1R1', '008340888', 'OBC', 'Racine', 'OBC', '', 5, 16, 4, 45, 1, 1, 2, 3, '2021-06-17 15:53:04', NULL, 4),
	(5, 'scat urbam', '1R1', '008340888', 'OBC', 'Racine', 'OBC', '', 5, 16, 4, 45, 1, 1, 2, 3, '2021-06-17 16:33:07', NULL, 4),
	(6, 'Point E', '2A2', '006241252', 'Racine INCO', 'Racine', 'RIC', '', 4, 18, 4, 45, 1, 1, 2, 1, '2021-06-28 12:50:38', NULL, NULL),
	(7, 'HLM ', '2A2', '002525626', 'CEA CABINET YOUSSOUPH BA', 'Mami Seyni', 'CCYB', '', 5, 18, 2, 45, 1, 1, 2, 2, '2021-06-28 15:28:40', NULL, 4),
	(8, 'HLM ', '2A2', '002525626', 'CEA CABINET YOUSSOUPH BA', 'Mami Seyni', 'CCYB', '', 5, 18, 2, 45, 1, 1, 2, 2, '2021-06-28 15:32:39', NULL, 4);
/*!40000 ALTER TABLE `td_contribuable_copie` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_depot
CREATE TABLE IF NOT EXISTS `td_depot` (
  `dep_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dep_annee_excercice` varchar(255) DEFAULT NULL,
  `dep_capitaux_propre` double DEFAULT NULL,
  `dep_ca` double DEFAULT NULL,
  `create_date_time` datetime DEFAULT NULL,
  `dep_date_soumission` datetime DEFAULT NULL,
  `etat` varchar(6) DEFAULT 'EC',
  `dep_numero` varchar(255) DEFAULT NULL,
  `dep_resultat_net` double DEFAULT NULL,
  `dep_total_bilan` double DEFAULT NULL,
  `dep_total_produit` double DEFAULT NULL,
  `dep_total_ttc` double DEFAULT NULL,
  `dep_con_id` bigint(20) DEFAULT NULL,
  `dep_cco_id` bigint(20) DEFAULT NULL,
  `dep_str_id` bigint(20) DEFAULT NULL,
  `dep_uti_id` bigint(20) DEFAULT NULL,
  `dep_uti_traitant_id` bigint(20) DEFAULT NULL,
  `etat_libelle` varchar(255) DEFAULT NULL,
  `dep_uti_receive_id` bigint(20) DEFAULT NULL,
  `dep_nb_pages` int(11) DEFAULT '0',
  PRIMARY KEY (`dep_id`),
  KEY `FKrlpcs366sy7j0o006ctc0cyh3` (`dep_con_id`),
  KEY `FKi5bllqlcjujkhetrmpwsechfk` (`dep_cco_id`),
  KEY `FKqi7fsoaemm9ehkkt3fr1rdhbf` (`dep_str_id`),
  KEY `FKao85vfxjlyijwrtshp3opgd7w` (`dep_uti_id`),
  KEY `FKc2igkdhucfx8w7xdu0bcv771f` (`dep_uti_traitant_id`),
  KEY `FKs8643xryxtf2k9rprhlpqloin` (`dep_uti_receive_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_depot : 8 rows
/*!40000 ALTER TABLE `td_depot` DISABLE KEYS */;
INSERT INTO `td_depot` (`dep_id`, `dep_annee_excercice`, `dep_capitaux_propre`, `dep_ca`, `create_date_time`, `dep_date_soumission`, `etat`, `dep_numero`, `dep_resultat_net`, `dep_total_bilan`, `dep_total_produit`, `dep_total_ttc`, `dep_con_id`, `dep_cco_id`, `dep_str_id`, `dep_uti_id`, `dep_uti_traitant_id`, `etat_libelle`, `dep_uti_receive_id`, `dep_nb_pages`) VALUES
	(1, '2020', -1000000, 1254000, '2021-06-03 14:20:27', '2021-06-03 14:20:27', 'VS', '2021000002', -12212121, 1000000000, 12121121, 50000, 1, 1, 2, 129, 129, 'En attente de visa', 129, 12),
	(2, '2019', 10, 10, '2021-06-03 16:20:01', '2021-06-03 16:20:01', 'VS', '2021000003', 10, 10, 10, 50000, 1, 2, 2, 129, 131, 'En attente de visa', 129, 12),
	(3, '2019', 12, 1, '2021-06-03 16:27:50', '2021-06-03 16:27:50', 'VS', '2021000004', 12, 12, 2, 50000, 1, 3, 2, 129, 129, 'En attente de visa', 129, 100),
	(4, '2020', 30000000, 50000000, '2021-06-17 15:51:02', '2021-06-17 15:51:02', 'VS', '2021000005', 69000000, 98000000, 25000000, 100000, 8, 4, 4, 140, 140, 'Visée', 140, 50),
	(5, '2020', 30000000, 50000000, '2021-06-17 16:11:54', '2021-06-17 16:11:54', 'VS', '2021000006', 40000000, 99000000, 25000000, 100000, 8, 5, 4, 140, 140, 'En attente de visa', 140, 50),
	(6, '2020', -5000000, 4500000, '2021-06-28 12:43:24', '2021-06-28 12:43:24', 'VS', '2021000007', 4000000, 99000000, 20000000, 50000, 9, 6, 4, 140, 140, 'Visée', 140, 1),
	(7, '2019', 5400000, 120000000, '2021-06-28 15:28:01', '2021-06-28 15:28:01', 'VS', '2021000008', 5000000, 10000000, 2500000, 250000, 10, 7, 4, 140, 140, 'Visée', 140, 10),
	(8, '2019', 45000000, 1220000, '2021-06-28 15:32:22', '2021-06-28 15:32:22', 'DE', '2021000009', 55222222, 15000000, 458888, 50000, 10, 8, 4, 140, NULL, 'En cours', 140, 10);
/*!40000 ALTER TABLE `td_depot` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_etalink
CREATE TABLE IF NOT EXISTS `td_etalink` (
  `eta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eta_annee_cloture_exercice` varchar(255) DEFAULT NULL,
  `eta_annee_n1` int(11) DEFAULT NULL,
  `eta_date_cloture` datetime DEFAULT NULL,
  `eta_derniere_date_cloture` datetime DEFAULT NULL,
  `create_date_time` datetime DEFAULT NULL,
  `eta_duree_n` int(11) DEFAULT NULL,
  `eta_dureen1` int(11) DEFAULT NULL,
  `etat` varchar(6) DEFAULT 'EC',
  `eta_nb_mois` int(11) DEFAULT NULL,
  `eta_date_ouverture` datetime DEFAULT NULL,
  `eta_derniere_date_ouverture` datetime DEFAULT NULL,
  `eta_con_id` bigint(20) DEFAULT NULL,
  `eta_str_id` bigint(20) DEFAULT NULL,
  `eta_uti_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`eta_id`),
  KEY `FK557wey7st2ueb6ag587t8q5xu` (`eta_con_id`),
  KEY `FKf7xvtnn9pr56u2nhcary06owd` (`eta_str_id`),
  KEY `FKs0fulv6lr599d1s56juwr4ynr` (`eta_uti_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table bd_orbusLink_visa.td_etalink : 23 rows
/*!40000 ALTER TABLE `td_etalink` DISABLE KEYS */;
INSERT INTO `td_etalink` (`eta_id`, `eta_annee_cloture_exercice`, `eta_annee_n1`, `eta_date_cloture`, `eta_derniere_date_cloture`, `create_date_time`, `eta_duree_n`, `eta_dureen1`, `etat`, `eta_nb_mois`, `eta_date_ouverture`, `eta_derniere_date_ouverture`, `eta_con_id`, `eta_str_id`, `eta_uti_id`) VALUES
	(1, '2020', 2019, '2021-05-21 00:00:00', '2021-06-02 00:00:00', '2021-06-08 16:40:57', 12, 11, 'EC', 12, '2021-04-14 00:00:00', '2020-11-03 00:00:00', 2, 1, 128),
	(2, '2020', 2019, '2021-05-21 00:00:00', '2021-06-02 00:00:00', '2021-06-08 16:41:16', 12, 11, 'GE', 12, '2021-04-14 00:00:00', '2020-11-03 00:00:00', 2, 1, 128),
	(3, '2020', 2019, '2021-05-21 00:00:00', '2021-06-02 00:00:00', '2021-06-08 16:42:11', 12, 11, 'GE', 12, '2021-04-14 00:00:00', '2020-11-03 00:00:00', 2, 1, 128),
	(4, '2020', 202019, '2019-12-31 00:00:00', '2018-12-31 00:00:00', '2021-06-09 09:16:16', 12, 12, 'EC', 12, '2019-01-09 00:00:00', '2018-01-01 00:00:00', 2, 1, 128),
	(5, '2020', 202019, '2019-12-31 00:00:00', '2018-12-31 00:00:00', '2021-06-09 09:16:25', 12, 12, 'EC', 12, '2019-01-09 00:00:00', '2018-01-01 00:00:00', 2, 1, 128),
	(6, '20', 2019, '2019-12-31 00:00:00', '2018-12-31 00:00:00', '2021-06-09 08:29:39', 12, 12, 'EC', 12, '2019-01-09 00:00:00', '2018-01-01 00:00:00', 2, NULL, NULL),
	(7, '20', 2019, '2019-12-31 00:00:00', '2018-12-31 00:00:00', '2021-06-09 08:29:39', 12, 12, 'EC', 12, '2019-01-09 00:00:00', '2018-01-01 00:00:00', 2, NULL, NULL),
	(8, '20', 2019, '2019-12-31 00:00:00', '2018-12-31 00:00:00', '2021-06-09 08:29:44', 12, 12, 'EC', 12, '2019-01-09 00:00:00', '2018-01-01 00:00:00', 2, NULL, NULL),
	(9, '2020', 202019, '2019-12-31 00:00:00', '2018-12-31 00:00:00', '2021-06-09 09:17:54', 12, 12, 'EC', 12, '2019-01-09 00:00:00', '2018-01-01 00:00:00', 2, 1, 128),
	(10, '2014', 202013, '2014-12-31 00:00:00', '2013-12-03 00:00:00', '2021-06-09 09:43:23', 12, 12, 'GE', 12, '2014-01-01 00:00:00', '2013-01-01 00:00:00', 2, 1, 128),
	(11, '2015', 202014, '2015-12-31 00:00:00', '2014-12-31 00:00:00', '2021-06-09 09:20:13', 12, 12, 'GE', 12, '2015-01-01 00:00:00', '2014-01-01 00:00:00', 1, 2, 129),
	(12, '2017', 202016, '2017-12-31 00:00:00', '2016-12-31 00:00:00', '2021-06-09 09:37:47', 12, 12, 'GE', 12, '0217-01-01 00:00:00', '2016-01-01 00:00:00', 1, 2, 129),
	(13, '2020', 202019, '2021-06-01 00:00:00', '2021-06-03 00:00:00', '2021-06-09 11:41:13', 12, 21, 'DE', 1, '2021-06-05 00:00:00', '2021-06-07 00:00:00', 1, NULL, 130),
	(14, '2018', 202017, '2017-12-09 00:00:00', '2018-01-09 00:00:00', '2021-06-09 11:08:26', 12, 12, 'GE', 12, '2017-01-09 00:00:00', '2018-01-09 00:00:00', 1, 2, 129),
	(15, '2020', 202019, '2021-06-05 00:00:00', '2021-06-04 00:00:00', '2021-06-09 11:57:31', 10, 11, 'DE', 10, '2021-06-05 00:00:00', '2021-06-04 00:00:00', 1, NULL, 130),
	(16, '2019', 202018, '2021-06-01 00:00:00', '2021-05-31 00:00:00', '2021-06-09 14:38:47', 10, 10, 'EC', 12, '2021-06-04 00:00:00', '2021-06-06 00:00:00', 1, NULL, 130),
	(17, '2020', 202019, '1997-05-11 00:00:00', '2021-06-01 00:00:00', '2021-06-09 14:09:32', 2, 2, 'EC', 10, '2021-06-05 00:00:00', '2021-06-05 00:00:00', 1, NULL, 130),
	(18, '2017', 202016, '2017-12-09 00:00:00', '2016-12-09 00:00:00', '2021-06-09 14:15:58', 12, 12, 'GE', 12, '2017-01-09 00:00:00', '2016-01-09 00:00:00', 1, NULL, 130),
	(19, '2020', 202019, '2020-12-14 00:00:00', '2019-12-14 00:00:00', '2021-06-14 15:37:38', 12, 12, 'GE', 12, '2020-01-14 00:00:00', '2019-01-14 00:00:00', 5, 3, 135),
	(20, '2019', 202018, '2019-12-14 00:00:00', '2018-12-14 00:00:00', '2021-06-14 15:45:26', 12, 12, 'GE', 11, '2019-01-14 00:00:00', '2018-01-14 00:00:00', 4, NULL, 138),
	(21, '2020', 202019, '2020-12-15 00:00:00', '2019-12-15 00:00:00', '2021-06-15 16:04:49', 10, 12, 'GE', 12, '2020-01-15 00:00:00', '2019-01-15 00:00:00', 7, 5, 141),
	(22, '2018', 202017, '2018-12-15 00:00:00', '2017-12-15 00:00:00', '2021-06-15 16:17:12', 10, 12, 'EC', 12, '2018-01-15 00:00:00', '2017-01-15 00:00:00', 6, 5, 141),
	(23, '2018', 202017, '2018-12-15 00:00:00', '2017-12-15 00:00:00', '2021-06-15 16:18:11', 10, 12, 'EC', 12, '2018-01-15 00:00:00', '2017-01-15 00:00:00', 6, 5, 141);
/*!40000 ALTER TABLE `td_etalink` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_info_rejet
CREATE TABLE IF NOT EXISTS `td_info_rejet` (
  `inf_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date_time` datetime DEFAULT NULL,
  `inf_libelle` varchar(255) DEFAULT NULL,
  `depot_dep_id` bigint(20) DEFAULT NULL,
  `inf_uti_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`inf_id`),
  KEY `FKelkbgvxq1wqtlccc27un2u9nt` (`depot_dep_id`),
  KEY `FKa7eyt5u02lghjd3hj4hu6cela` (`inf_uti_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_info_rejet : 0 rows
/*!40000 ALTER TABLE `td_info_rejet` DISABLE KEYS */;
/*!40000 ALTER TABLE `td_info_rejet` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_info_visa
CREATE TABLE IF NOT EXISTS `td_info_visa` (
  `inv_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date_time` datetime DEFAULT NULL,
  `inv_libelle` varchar(255) DEFAULT NULL,
  `inv_uti_id` bigint(20) DEFAULT NULL,
  `depot_dep_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`inv_id`),
  KEY `FKhf4kbaabm7uvwrcwqbp0fnj7m` (`inv_uti_id`),
  KEY `FK2n1ymehifajgql0di1dnksx39` (`depot_dep_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_info_visa : 7 rows
/*!40000 ALTER TABLE `td_info_visa` DISABLE KEYS */;
INSERT INTO `td_info_visa` (`inv_id`, `create_date_time`, `inv_libelle`, `inv_uti_id`, `depot_dep_id`) VALUES
	(1, '2021-06-03 14:21:08', 'Demande: 2021000002visé par Coumba Souna FALL(TOGAF CAOMPTA 2)', 129, 1),
	(2, '2021-06-03 16:21:56', 'Demande: 2021000003visé par Mariama FALL(TOGAF CAOMPTA 2)', 131, 2),
	(3, '2021-06-03 17:08:18', 'Demande: 2021000004visé par Coumba Souna FALL(TOGAF CAOMPTA 2)', 129, 3),
	(4, '2021-06-17 15:54:38', 'Demande: 2021000005visé par Cheikh Diop (Audit et conseil international)', 140, 4),
	(5, '2021-06-17 16:34:21', 'Demande: 2021000006visé par Cheikh Diop (Audit et conseil international)', 140, 5),
	(6, '2021-06-28 14:59:50', 'Demande: 2021000007visé par Cheikh Diop (Audit et conseil international)', 140, 6),
	(7, '2021-06-28 15:29:07', 'Demande: 2021000008visé par Cheikh Diop (Audit et conseil international)', 140, 7);
/*!40000 ALTER TABLE `td_info_visa` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_numero_sequence_depot
CREATE TABLE IF NOT EXISTS `td_numero_sequence_depot` (
  `nsd_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nsd_annee` bigint(20) DEFAULT NULL,
  `nsd_numero` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`nsd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_numero_sequence_depot : 0 rows
/*!40000 ALTER TABLE `td_numero_sequence_depot` DISABLE KEYS */;
/*!40000 ALTER TABLE `td_numero_sequence_depot` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_piece_joint
CREATE TABLE IF NOT EXISTS `td_piece_joint` (
  `pij_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pij_libelle` varchar(255) DEFAULT NULL,
  `pij_libelle_last_update` varchar(255) DEFAULT NULL,
  `pij_name` varchar(255) DEFAULT NULL,
  `pij_name_last_update` varchar(255) DEFAULT NULL,
  `pij_path` varchar(255) DEFAULT NULL,
  `pij_path_last_update` varchar(255) DEFAULT NULL,
  `pij_statut` varchar(255) DEFAULT NULL,
  `pij_syc_id` varchar(255) DEFAULT NULL,
  `pij_type_fichier` varchar(255) DEFAULT NULL,
  `pij_depot` bigint(20) DEFAULT NULL,
  `pij_nature_fichier` bigint(20) DEFAULT NULL,
  `pij_etalink` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pij_id`),
  KEY `FKa8con7apwg5r9iaqii1kol98` (`pij_depot`),
  KEY `FKdjw6c2uuvqnom9r726kpuxsiv` (`pij_nature_fichier`),
  KEY `FK3khcjwl03w4lseq3pork3nbac` (`pij_etalink`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_piece_joint : 52 rows
/*!40000 ALTER TABLE `td_piece_joint` DISABLE KEYS */;
INSERT INTO `td_piece_joint` (`pij_id`, `pij_libelle`, `pij_libelle_last_update`, `pij_name`, `pij_name_last_update`, `pij_path`, `pij_path_last_update`, `pij_statut`, `pij_syc_id`, `pij_type_fichier`, `pij_depot`, `pij_nature_fichier`, `pij_etalink`) VALUES
	(1, '000005951_4H2_EtafiEnExcel_2020', NULL, '1622730027273_000005951', NULL, 'https://196.207.202.52:7070/upload/1622730027273_000005951', NULL, '31', '1', NULL, 1, 3, NULL),
	(2, '000005951_4H2_AutresFichier_2020', NULL, '1622730031961_000005951', NULL, 'https://196.207.202.52:7070/upload/1622730031961_000005951', NULL, '31', '1', NULL, 1, 4, NULL),
	(3, 'attestation_Signee_000005951_1622730064395.pdf', NULL, 'attestation_Signee_000005951_1622730064395.pdf', NULL, 'https://196.207.202.52:7070/upload/1622730064395_000005951', NULL, '31', '1', NULL, 1, 1, NULL),
	(4, 'EFPDF_Signee_000005951_1622730068366.pdf', NULL, 'EFPDF_Signee_000005951_1622730068366.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_000005951_1622730068366.pdf', NULL, '31', '1', NULL, 1, 2, NULL),
	(5, '000005951_4H2_EtafiEnExcel_2019', NULL, '1622737201489_000005951', NULL, 'https://196.207.202.52:7070/upload/1622737201489_000005951', NULL, '31', '1', NULL, 2, 3, NULL),
	(6, 'attestation_Signee_000005951_1622737314191.pdf', NULL, 'attestation_Signee_000005951_1622737314191.pdf', NULL, 'https://196.207.202.52:7070/upload/1622737314191_000005951', NULL, '31', '1', NULL, 2, 1, NULL),
	(7, 'EFPDF_Signee_000005951_1622737315687.pdf', NULL, 'EFPDF_Signee_000005951_1622737315687.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_000005951_1622737315687.pdf', NULL, '31', '1', NULL, 2, 2, NULL),
	(8, '000005951_4H2_EtafiEnExcel_2019', NULL, '1622737669708_000005951', NULL, 'https://196.207.202.52:7070/upload/1622737669708_000005951', NULL, '31', '1', NULL, 3, 3, NULL),
	(9, 'attestation_Signee_000005951_1622740096836.pdf', NULL, 'attestation_Signee_000005951_1622740096836.pdf', NULL, 'https://196.207.202.52:7070/upload/1622740096836_000005951', NULL, '31', '1', NULL, 3, 1, NULL),
	(10, 'EFPDF_Signee_000005951_1622740098146.pdf', NULL, 'EFPDF_Signee_000005951_1622740098146.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_000005951_1622740098146.pdf', NULL, '31', '1', NULL, 3, 2, NULL),
	(11, '000000018_5G5ETALINK_2020', NULL, 'F1623170714657_000000018_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623170714657_000000018_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 16, 3),
	(12, 'G000000018_5G5ETAFI_2020', NULL, '1623170730800_Etalink_000000018_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623170730800_Etalink_000000018_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 17, 3),
	(13, '000000018_5G5ETALINK_2020', NULL, 'F1623171297170_000000018_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623171297170_000000018_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 16, 2),
	(14, 'G000000018_5G5ETAFI_2020', NULL, '1623171301582_Etalink_000000018_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623171301582_Etalink_000000018_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 17, 2),
	(15, '000000018_5G5ETALINK_2014', NULL, 'F1623231974587_000000018_annee_2014.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623231974587_000000018_annee_2014.xlsm', NULL, '31', '1', NULL, NULL, 16, 10),
	(16, '000005951_4H2ETALINK_15', NULL, '1623230412692_Etalink_000005951_annee_2015.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623230412692_Etalink_000005951_annee_2015.xlsm', NULL, '31', '1', NULL, NULL, 15, 11),
	(17, '000005951_4H2ETALINK_2015', NULL, 'F1623230857301_000005951_annee_2015.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623230857301_000005951_annee_2015.xlsm', NULL, '31', '1', NULL, NULL, 16, 11),
	(18, '2021000012_000005951SEN_ETAFI_2015', NULL, '1623230865817_Etalink_000005951_annee_2015.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623230865817_Etalink_000005951_annee_2015.xlsm', NULL, '31', '1', NULL, NULL, 17, 11),
	(19, '2021000012_000005951SEN_ETAFI_2015', NULL, '1623230910315_Etalink_000005951_annee_2015.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623230910315_Etalink_000005951_annee_2015.xlsm', NULL, '31', '1', NULL, NULL, 17, 11),
	(20, '000005951_4H2ETALINK_17', NULL, '1623231467008_Etalink_000005951_annee_2017.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623231467008_Etalink_000005951_annee_2017.xlsm', NULL, '31', '1', NULL, NULL, 15, 12),
	(21, '000005951_4H2ETALINK_2017', NULL, 'F1623231518098_000005951_annee_2017.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623231518098_000005951_annee_2017.xlsm', NULL, '31', '1', NULL, NULL, 16, 12),
	(22, '2021000013_000005951SEN_ETAFI_2017', NULL, '1623231549333_Etalink_000005951_annee_2017.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623231549333_Etalink_000005951_annee_2017.xlsm', NULL, '31', '1', NULL, NULL, 17, 12),
	(23, '000005951_4H2ETALINK_18', NULL, '1623236905916_Etalink_000005951_annee_2018.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623236905916_Etalink_000005951_annee_2018.xlsm', NULL, '31', '1', NULL, NULL, 15, 14),
	(24, '000005951_4H2ETALINK_2018', NULL, 'F1623237040882_000005951_annee_2018.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623237040882_000005951_annee_2018.xlsm', NULL, '31', '1', NULL, NULL, 16, 14),
	(25, '2021000015_000005951SEN_ETAFI_2018', NULL, '1623237048108_Etalink_000005951_annee_2018.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623237048108_Etalink_000005951_annee_2018.xlsm', NULL, '31', '1', NULL, NULL, 17, 14),
	(26, '000005951_4H2ETALINK_19', NULL, '1623249527470_Etalink_000005951_annee_2019.xlsm', NULL, 'C://Users//mbthiam//PROJECTS//PORTAIL-VISA//visa_v2_back//upload/1623249527470_Etalink_000005951_annee_2019.xlsm', NULL, '31', '1', NULL, NULL, 15, 16),
	(27, '000005951_4H2ETALINK_20', NULL, '1623247771804_Etalink_000005951_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623247771804_Etalink_000005951_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 15, 17),
	(28, '000005951_4H2ETALINK_17', NULL, '1623248158519_Etalink_000005951_annee_2017.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623248158519_Etalink_000005951_annee_2017.xlsm', NULL, '31', '1', NULL, NULL, 15, 18),
	(29, '000005951_4H2ETALINK_2017', NULL, 'F1623248183040_000005951_annee_2017.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623248183040_000005951_annee_2017.xlsm', NULL, '31', '1', NULL, NULL, 16, 18),
	(30, '2021000019_000005951SEN_ETAFI_2017', NULL, '1623248189555_Etalink_000005951_annee_2017.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623248189555_Etalink_000005951_annee_2017.xlsm', NULL, '31', '1', NULL, NULL, 17, 18),
	(31, '000345952_4H2ETALINK_20', NULL, '1623685058234_Etalink_000345952_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623685058234_Etalink_000345952_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 15, 19),
	(32, '000345952_4H2ETALINK_2020', NULL, 'F1623685247354_000345952_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623685247354_000345952_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 16, 19),
	(33, '2021000020_000345952SEN_ETAFI_2020', NULL, '1623685264315_Etalink_000345952_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623685264315_Etalink_000345952_annee_2020.xlsm', NULL, '31', '1', NULL, NULL, 17, 19),
	(34, '000340034_4L5ETALINK_19', NULL, '1623685526057_Etalink_000340034_annee_2019.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623685526057_Etalink_000340034_annee_2019.xlsm', NULL, '31', '1', NULL, NULL, 15, 20),
	(35, '000340034_4L5ETALINK_2019', NULL, 'F1623685598142_000340034_annee_2019.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623685598142_000340034_annee_2019.xlsm', NULL, '31', '1', NULL, NULL, 16, 20),
	(36, '2021000021_000340034SEN_ETAFI_2019', NULL, '1623685610267_Etalink_000340034_annee_2019.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623685610267_Etalink_000340034_annee_2019.xlsm', NULL, '31', '1', NULL, NULL, 17, 20),
	(37, '000003418_5G5ETALINK_20', NULL, '1623773089014_Etalink_000003418_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/1623773089014_Etalink_000003418_annee_2020.xlsm', NULL, '31', '2', NULL, NULL, 15, 21),
	(38, '000003418_5G5ETALINK_2020', NULL, 'F1623773344420_000003418_annee_2020.xlsm', NULL, 'https://196.207.202.52:7070/upload/F1623773344420_000003418_annee_2020.xlsm', NULL, '31', '2', NULL, NULL, 16, 21),
	(39, '008340888_1R1_EtafiEnExcel_2020', NULL, '1623945060194_008340888', NULL, 'https://196.207.202.52:7070/upload/1623945060194_008340888', NULL, '31', '1', NULL, 4, 3, NULL),
	(40, '008340888_1R1_AutresFichier_2020', NULL, '1623945120643_008340888', NULL, 'https://196.207.202.52:7070/upload/1623945120643_008340888', NULL, '31', '1', NULL, 4, 4, NULL),
	(41, 'attestation_Signee_008340888_1623945263786.pdf', NULL, 'attestation_Signee_008340888_1623945263786.pdf', NULL, 'https://196.207.202.52:7070/upload/1623945263786_008340888', NULL, '31', '1', NULL, 4, 1, NULL),
	(42, 'EFPDF_Signee_008340888_1623945278595.pdf', NULL, 'EFPDF_Signee_008340888_1623945278595.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_008340888_1623945278595.pdf', NULL, '31', '1', NULL, 4, 2, NULL),
	(43, '008340888_1R1_EtafiEnExcel_2020', NULL, '1623946314363_008340888', NULL, 'https://196.207.202.52:7070/upload/1623946314363_008340888', NULL, '31', '1', NULL, 5, 3, NULL),
	(44, 'attestation_Signee_008340888_1623947658300.pdf', NULL, 'attestation_Signee_008340888_1623947658300.pdf', NULL, 'https://196.207.202.52:7070/upload/1623947658300_008340888', NULL, '31', '1', NULL, 5, 1, NULL),
	(45, 'EFPDF_Signee_008340888_1623947661011.pdf', NULL, 'EFPDF_Signee_008340888_1623947661011.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_008340888_1623947661011.pdf', NULL, '31', '1', NULL, 5, 2, NULL),
	(46, '006241252_2A2_EtafiEnExcel_2020', NULL, '1624884609367_006241252', NULL, 'https://196.207.202.52:7070/upload/1624884609367_006241252', NULL, '31', '1', NULL, 6, 3, NULL),
	(47, 'attestation_Signee_006241252_1624892386200.pdf', NULL, 'attestation_Signee_006241252_1624892386200.pdf', NULL, 'https://196.207.202.52:7070/upload/1624892386200_006241252', NULL, '31', '1', NULL, 6, 1, NULL),
	(48, 'EFPDF_Signee_006241252_1624892389622.pdf', NULL, 'EFPDF_Signee_006241252_1624892389622.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_006241252_1624892389622.pdf', NULL, '31', '1', NULL, 6, 2, NULL),
	(49, '002525626_2A2_EtafiEnExcel_2019', NULL, '1624894081317_002525626', NULL, 'https://196.207.202.52:7070/upload/1624894081317_002525626', NULL, '31', '1', NULL, 7, 3, NULL),
	(50, 'attestation_Signee_002525626_1624894146009.pdf', NULL, 'attestation_Signee_002525626_1624894146009.pdf', NULL, 'https://196.207.202.52:7070/upload/1624894146009_002525626', NULL, '31', '1', NULL, 7, 1, NULL),
	(51, 'EFPDF_Signee_002525626_1624894147050.pdf', NULL, 'EFPDF_Signee_002525626_1624894147050.pdf', NULL, 'https://196.207.202.52:7070/upload/EFPDF_Signee_002525626_1624894147050.pdf', NULL, '31', '1', NULL, 7, 2, NULL),
	(52, '002525626_2A2_EtafiEnExcel_2019', NULL, '1624894342289_002525626', NULL, 'https://196.207.202.52:7070/upload/1624894342289_002525626', NULL, '31', '1', NULL, 8, 3, NULL);
/*!40000 ALTER TABLE `td_piece_joint` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_rejet_def
CREATE TABLE IF NOT EXISTS `td_rejet_def` (
  `red_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date_time` datetime DEFAULT NULL,
  `red_libelle` varchar(255) DEFAULT NULL,
  `red_dep_id` bigint(20) DEFAULT NULL,
  `red_uti_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`red_id`),
  KEY `FKbsh0vv0w5626p5vxktwf55i6w` (`red_dep_id`),
  KEY `FKi1ngabf5kff60yv547xk35n12` (`red_uti_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_rejet_def : 0 rows
/*!40000 ALTER TABLE `td_rejet_def` DISABLE KEYS */;
/*!40000 ALTER TABLE `td_rejet_def` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_structure
CREATE TABLE IF NOT EXISTS `td_structure` (
  `str_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `str_adresse` varchar(255) DEFAULT NULL,
  `str_fax` varchar(255) DEFAULT NULL,
  `str_ninea` varchar(255) DEFAULT NULL,
  `str_nom_ou_raison_social` varchar(255) DEFAULT NULL,
  `str_telephone` varchar(255) DEFAULT NULL,
  `str_cat_id` bigint(20) DEFAULT NULL,
  `str_numero_rccm` varchar(255) DEFAULT NULL,
  `str_qsi_id` bigint(20) DEFAULT NULL,
  `con_ass_id` bigint(20) DEFAULT NULL,
  `str_ass_id` bigint(20) DEFAULT NULL,
  `str_abonnement` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`str_id`),
  UNIQUE KEY `UK_islo95u1xmv1wnrclwk3qpgwb` (`str_ninea`),
  UNIQUE KEY `UK_2ns0mv5id1d61mabfexhpyryk` (`str_numero_rccm`),
  KEY `FK3mp7y5ret80d1yore6t45mrlt` (`str_cat_id`),
  KEY `FKfn9rp6lidnpxv6u7bbcoy2md0` (`con_ass_id`),
  KEY `FK3pcl7ypjqqplbsmsisduqootp` (`str_ass_id`),
  KEY `FK49b25lc6wsx2b0cm5yduqkcsp` (`str_qsi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_structure : 5 rows
/*!40000 ALTER TABLE `td_structure` DISABLE KEYS */;
INSERT INTO `td_structure` (`str_id`, `str_adresse`, `str_fax`, `str_ninea`, `str_nom_ou_raison_social`, `str_telephone`, `str_cat_id`, `str_numero_rccm`, `str_qsi_id`, `con_ass_id`, `str_ass_id`, `str_abonnement`) VALUES
	(1, 'Point E', NULL, '000000000', 'SCRUM COMPTA SA', '', 1, 'SNDKR122122', 2, NULL, 2, b'1'),
	(2, 'Point E', NULL, '000000034', 'TOGAF CAOMPTA 2', '', 2, 'SNDKR1221FF', 1, NULL, 2, b'1'),
	(3, 'Point E', NULL, '000000076', 'SEN COMPTA SA', '', 2, 'SNDKR12212', 2, NULL, 1, b'1'),
	(4, 'Sicap Foire - Lot n 72', NULL, '006128252', 'Audit et conseil international', '', 2, 'SN.DKR.2016.M.27717', 2, NULL, 2, b'0'),
	(5, 'Point E Allée Seydou Nourou Tall', NULL, '000000050', 'ABC COMPTA', '', 2, 'SNDKR122122.3', 2, NULL, 2, b'1');
/*!40000 ALTER TABLE `td_structure` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. td_utilisateur
CREATE TABLE IF NOT EXISTS `td_utilisateur` (
  `uti_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date_time` datetime DEFAULT NULL,
  `uti_delagation_id` varchar(255) DEFAULT NULL,
  `uti_email` varchar(255) DEFAULT NULL,
  `uti_first_connection` bit(1) DEFAULT NULL,
  `uti_matricule` varchar(255) DEFAULT NULL,
  `uti_nom` varchar(255) DEFAULT NULL,
  `uti_password` varchar(255) DEFAULT NULL,
  `uti_prenom` varchar(255) DEFAULT NULL,
  `uti_signature_key_id` varchar(255) DEFAULT NULL,
  `uti_statut` bit(1) DEFAULT NULL,
  `uti_telephone` varchar(255) DEFAULT NULL,
  `uti_update_date_time` datetime DEFAULT NULL,
  `uti_con_id` bigint(20) DEFAULT NULL,
  `uti_pro_id` bigint(20) DEFAULT NULL,
  `uti_str_id` bigint(20) DEFAULT NULL,
  `update_date_time` datetime DEFAULT NULL,
  `uti_abonnement` bit(1) DEFAULT NULL,
  `date_abonnement` datetime DEFAULT NULL,
  `uti_delagation_id_prof` varchar(255) DEFAULT NULL,
  `uti_signature_key_id_prof` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uti_id`),
  UNIQUE KEY `UK_btgcwr64b7muuwjs2q2pbgecg` (`uti_email`),
  KEY `FKo6jcsvqjyb5loqlqxjelwmrl8` (`uti_con_id`),
  KEY `FKdj5vdsyttvg97kbslgvq4d1g1` (`uti_pro_id`),
  KEY `FKovmssu13usp5t7uwkwgqngurq` (`uti_str_id`)
) ENGINE=MyISAM AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.td_utilisateur : 21 rows
/*!40000 ALTER TABLE `td_utilisateur` DISABLE KEYS */;
INSERT INTO `td_utilisateur` (`uti_id`, `create_date_time`, `uti_delagation_id`, `uti_email`, `uti_first_connection`, `uti_matricule`, `uti_nom`, `uti_password`, `uti_prenom`, `uti_signature_key_id`, `uti_statut`, `uti_telephone`, `uti_update_date_time`, `uti_con_id`, `uti_pro_id`, `uti_str_id`, `update_date_time`, `uti_abonnement`, `date_abonnement`, `uti_delagation_id_prof`, `uti_signature_key_id_prof`) VALUES
	(1, '2021-03-23 18:53:38', NULL, 'alioune@yopmail.com', b'0', NULL, 'admin', '$2a$10$es5Lx8kfhJ016.mHG6Y1NulT6aWjVc3eZunqFgoK5Ufaw58kbCg16', 'Alioune', NULL, b'1', '771627973', NULL, NULL, 1, NULL, '2021-04-08 00:15:24', b'0', NULL, NULL, NULL),
	(128, '2021-06-03 14:13:17', '105964', 'ec1@yopmail.com', b'0', 'EC202101', 'SENE', '$2a$10$vcnUKwbijJ6cisAQq/6/yu1.4kZx3ycJOD.Mh9lsqVmNDFRUnMtlG', 'Mariama', 'cle_02FOR_App_136948', b'1', '777777777', NULL, NULL, 3, 1, '2021-06-03 14:23:48', b'0', '2021-06-03 14:13:17', '105964', 'cle_02FOR_App_136948'),
	(129, '2021-06-03 14:14:22', '105964', 'ca1@yopmail.com', b'0', 'EC202102', 'FALL', '$2a$10$MydVQv7a.bfEpUT8JgNE7.qusmSOC0L4WMbQuAGAzk3IkUq5xfMni', 'Coumba Souna', 'cle_02FOR_App_136948', b'1', '777777777', NULL, NULL, 2, 2, '2021-06-03 17:07:20', b'0', '2021-06-03 14:14:22', '105964', 'cle_02FOR_App_136948'),
	(130, '2021-06-03 14:19:40', NULL, 'dec1@yopmail.com', b'0', NULL, 'FALL', '$2a$10$nM0sAQlLdNDH2sG5s5N4UuKbTg.MNqATAf3zXlGTt3mg5Mv9Pj1DC', 'SIDY', NULL, b'0', '777777777', NULL, 1, 5, NULL, '2021-06-03 14:25:00', b'0', '2021-06-03 14:19:40', NULL, NULL),
	(131, '2021-06-03 16:17:31', '', 'sup2@yopmail.com', b'0', '0022', 'FALL', '$2a$10$/RHN/IaWIFLQh8TAgg3NN.Rq.QydfoZB4Fl1kcfAknfVPT093YdIe', 'Mariama', '', b'0', '777777777', NULL, NULL, 4, 2, '2021-07-29 15:19:51', b'0', '2021-06-03 16:17:31', '', ''),
	(132, '2021-06-07 10:40:21', NULL, 'asupport@yopmail.com', b'0', NULL, 'asupport', '$2a$10$UXLdURK5jA6pXobMpu4uzOpZKBWd8Fzv6BIaC1x6S03xztC3cy0yC', 'asupport', NULL, b'1', '777777777', NULL, NULL, 7, NULL, '2021-06-07 10:41:18', b'0', '2021-06-07 10:40:21', NULL, NULL),
	(133, '2021-06-08 16:29:16', NULL, 'supetalink@yopmail.com', b'0', NULL, 'DIOP', '$2a$10$FeUBL.JzAwxIKtdHwR0Ou.kPMjiGFVkteGbHPmPs5/RIEK4AHyGfG', 'ASS', NULL, b'1', '777777777', NULL, NULL, 7, NULL, '2021-06-08 16:35:49', b'0', '2021-06-08 16:29:16', NULL, NULL),
	(134, '2021-06-08 16:39:51', NULL, 'dec3@yopmail.com', b'0', NULL, 'DIOP', '$2a$10$rt9NYYq4XveHWteKHOOUOetICo5yKrXbJELK/1tM/H6diYxksRmwC', 'Ramatoulaye', NULL, b'0', '777777777', NULL, 2, 5, NULL, '2021-06-08 16:39:51', b'0', '2021-06-08 16:39:51', NULL, NULL),
	(135, '2021-06-09 11:14:31', '105964', 'cabinet3@yopmail.com', b'0', 'EC202100', 'SANE', '$2a$10$0CC2f0fDnXniZjulySbyrerx45XWRbVFKvd/9BOIhBi3DdTFtUlLu', 'Makhtar', 'cle_02FOR_App_136948', b'1', '777777777', NULL, NULL, 3, 3, '2021-06-09 11:15:19', b'0', '2021-06-09 11:14:31', '105964', 'cle_02FOR_App_136948'),
	(136, '2021-06-09 11:16:21', NULL, 'supportetalink@yopmail.com', b'0', NULL, 'Assane', '$2a$10$ToWTYrHs.UaumHtzoVBpDuxYCt/E9fti4hJ0otgmNOluPEvCOHicG', 'TALL', NULL, b'1', '777777777', NULL, NULL, 7, NULL, '2021-06-09 12:04:59', b'0', '2021-06-09 11:16:21', NULL, NULL),
	(137, '2021-06-09 11:23:14', NULL, 'dec5@yopmail.com', b'0', NULL, 'FALL', '$2a$10$vhXPmD0JMWoq/S3LilAdtuGXwnmV1re1yvkOP78az1MgQjSrzd4e2', 'Oumy', NULL, b'0', '777777777', NULL, 3, 5, NULL, '2021-06-09 11:29:16', b'0', '2021-06-09 11:23:14', NULL, NULL),
	(138, '2021-06-09 11:26:06', NULL, 'dec7@yopmail.com', b'0', NULL, 'GUEYE', '$2a$10$C0at2rs2KOz8rjGFHEsaj.O0s9beqvCHFmps0pwpaAaB4eAmDLbR6', 'Ramatoulaye', NULL, b'0', '777777777', NULL, 4, 5, NULL, '2021-06-09 11:27:51', b'0', '2021-06-09 11:26:06', NULL, NULL),
	(139, '2021-06-09 12:19:32', NULL, 'dec6@yopmail.com', b'0', NULL, 'TINE', '$2a$10$jLap0LnRooO.WU7M97wXzOEm8DegxTt.uVQN2I7EvO67mW347X8eq', 'Amadou', NULL, b'0', '777777777', NULL, 5, 5, NULL, '2021-06-09 11:32:41', b'0', '2021-06-09 12:19:32', NULL, NULL),
	(140, '2021-06-11 12:21:48', '105964', 'cheikh@yopmail.com', b'0', 'EC 2001 0041', 'Diop ', '$2a$10$PLvxne4cWXSKZfv34rqxruyy39znqgS0KUExBGR8MsKtbBjwIikbi', 'Cheikh', 'cle_02FOR_App_136948', b'1', '774071548', NULL, NULL, 3, 4, '2021-06-17 15:33:25', b'0', '2021-06-11 12:21:48', '105964', 'cle_02FOR_App_136948'),
	(141, '2021-06-15 11:27:00', '105964', 'cabinet4@yopmail.com', b'0', 'EC2021123333', 'DIOUF', '$2a$10$FCqyPwVarDCaBXIQh/iTzuwZ.2WdGOcbrnh3ZTrSLzcQLexv2rvVm', 'Abasse', 'cle_02FOR_App_136948', b'1', '777777777', NULL, NULL, 3, 5, '2021-06-15 11:34:53', b'0', '2021-06-15 11:27:00', '105964', 'cle_02FOR_App_136948'),
	(142, '2021-06-15 11:38:16', NULL, 'client1@yopmail.com', b'0', NULL, 'GUEYE', '$2a$10$TWMjK37hazDx7nu5EtnOl.5NWpJbpNiFBtwqEWcKJrcBKpnWjizCG', 'Samba S', NULL, b'0', '777777777', NULL, 6, 5, NULL, '2021-06-15 11:43:54', b'0', '2021-06-15 11:38:16', NULL, NULL),
	(143, '2021-06-15 11:47:52', NULL, 'client2@yopmail.com', b'0', NULL, 'SOUMARE', '$2a$10$HqpYZ3YoW5eNYa/PAZ16auTfzBvuU9DSr3jZ/cUcBpUwqpfNzeP96', 'Coumba Souna', NULL, b'0', '777777777', NULL, 7, 5, NULL, '2021-06-15 11:57:21', b'0', '2021-06-15 11:47:52', NULL, NULL),
	(144, '2021-06-17 15:44:46', NULL, 'moussa@yopmail.com', b'0', NULL, 'Sarr', '$2a$10$..UyJmjgY5sQlAvhdLYiWe95SITO.kYYvwfN3y24B9lYTSuuSWFQC', 'Moussa', NULL, b'0', '772534401', NULL, 8, 5, NULL, '2021-06-17 16:06:00', b'0', '2021-06-17 15:44:46', NULL, NULL),
	(145, '2021-06-28 12:35:44', NULL, 'seck@yopmail.com', b'0', NULL, 'SECK', '$2a$10$zlmzds.g5FYL.XUWOARql.lle0jvtOr/QVTc7iWKGLM.ZQ3X.R3e.', 'Racine', NULL, b'0', '774071548', NULL, 9, 5, NULL, '2021-06-28 12:39:34', b'0', '2021-06-28 12:35:44', NULL, NULL),
	(146, '2021-06-28 15:18:24', NULL, 'seyni@yopmail.com', b'0', NULL, 'Ndiaye', '$2a$10$rt9NYYq4XveHWteKHOOUOetICo5yKrXbJELK/1tM/H6diYxksRmwC', 'Mami Seyni', NULL, b'0', '774190792', NULL, 10, 5, NULL, '2021-06-28 15:18:24', b'0', '2021-06-28 15:18:24', NULL, NULL),
	(147, '2021-07-29 15:23:37', NULL, 'sup3@yopmail.com', b'0', NULL, 'seck', '$2a$10$rt9NYYq4XveHWteKHOOUOetICo5yKrXbJELK/1tM/H6diYxksRmwC', 'wally', NULL, b'0', '774071548', NULL, 11, 5, NULL, '2021-07-29 15:23:37', b'0', '2021-07-29 15:23:37', NULL, NULL);
/*!40000 ALTER TABLE `td_utilisateur` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_activite_principale
CREATE TABLE IF NOT EXISTS `tp_activite_principale` (
  `acp_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `acp_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_activite_principale : 9 rows
/*!40000 ALTER TABLE `tp_activite_principale` DISABLE KEYS */;
INSERT INTO `tp_activite_principale` (`acp_id`, `acp_libelle`) VALUES
	(1, 'Divers'),
	(2, 'Services fournis aux entreprises'),
	(3, 'Hôtels, bars et restaurants'),
	(4, 'Commerce'),
	(5, 'Bâtiments et Travaux Publiques'),
	(6, 'Autres Industries'),
	(7, 'Industries textiles'),
	(8, 'Industries alimentaires'),
	(9, 'Dématérialisation');
/*!40000 ALTER TABLE `tp_activite_principale` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_associe
CREATE TABLE IF NOT EXISTS `tp_associe` (
  `ass_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ass_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ass_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table bd_orbusLink_visa.tp_associe : 2 rows
/*!40000 ALTER TABLE `tp_associe` DISABLE KEYS */;
INSERT INTO `tp_associe` (`ass_id`, `ass_libelle`) VALUES
	(1, 'Associé unique'),
	(2, 'Plusieurs associés');
/*!40000 ALTER TABLE `tp_associe` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_bareme_cout_visa
CREATE TABLE IF NOT EXISTS `tp_bareme_cout_visa` (
  `bar_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bar_date_debut_validite` date DEFAULT NULL,
  `bar_date_fin_validite` date DEFAULT NULL,
  `bar_max` bigint(20) DEFAULT NULL,
  `bar_min` bigint(20) DEFAULT NULL,
  `bar_montant` double DEFAULT NULL,
  `bar_str_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`bar_id`),
  KEY `FK9meny38gj397u55cevrww6tmi` (`bar_str_id`)
) ENGINE=MyISAM AUTO_INCREMENT=273 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_bareme_cout_visa : 9 rows
/*!40000 ALTER TABLE `tp_bareme_cout_visa` DISABLE KEYS */;
INSERT INTO `tp_bareme_cout_visa` (`bar_id`, `bar_date_debut_validite`, `bar_date_fin_validite`, `bar_max`, `bar_min`, `bar_montant`, `bar_str_id`) VALUES
	(48, '2018-01-05', '2018-01-31', 1000000000, 750000001, 1200000, 1),
	(49, '2018-01-01', '2018-01-31', 750000000, 500000001, 750000, 1),
	(50, '2018-01-01', '2018-01-31', 500000000, 250000001, 550000, 2),
	(51, '2018-01-01', '2018-01-31', 250000000, 150000001, 350000, 2),
	(52, '2018-01-01', '2018-01-31', 150000000, 100000001, 250000, 1),
	(53, '2018-01-01', '2018-01-31', 100000000, 60000001, 175000, 2),
	(54, '2018-01-01', '2018-01-31', 60000000, 40000001, 100000, 1),
	(55, '2018-01-01', '2018-01-31', 40000000, 20000001, 75000, 1),
	(56, '2018-01-01', '2018-01-31', 20000000, 0, 50000, 2);
/*!40000 ALTER TABLE `tp_bareme_cout_visa` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_categorie
CREATE TABLE IF NOT EXISTS `tp_categorie` (
  `cat_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cat_libelle` varchar(255) DEFAULT NULL,
  `cat_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_categorie : 4 rows
/*!40000 ALTER TABLE `tp_categorie` DISABLE KEYS */;
INSERT INTO `tp_categorie` (`cat_id`, `cat_libelle`, `cat_code`) VALUES
	(1, 'Expert-Comptable', NULL),
	(2, 'Cabinet Expert-Comptable', NULL),
	(3, 'Cabinet Comptable agréé', NULL),
	(4, 'Comptable agréé', NULL);
/*!40000 ALTER TABLE `tp_categorie` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_centre_service_fiscal
CREATE TABLE IF NOT EXISTS `tp_centre_service_fiscal` (
  `csf_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `csf_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`csf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_centre_service_fiscal : 26 rows
/*!40000 ALTER TABLE `tp_centre_service_fiscal` DISABLE KEYS */;
INSERT INTO `tp_centre_service_fiscal` (`csf_id`, `csf_libelle`) VALUES
	(1, 'CENTRE DES SERVICES FISCAUXDAKAR-PLATEAU'),
	(2, 'CENTRE DES SERVICES FISCAUX DE LOUGA'),
	(3, 'CENTRE DES SERVICES FISCAUX DE THIES'),
	(4, 'CENTRE DES SERVICES FISCAUX DE ZIGUINCHOR'),
	(5, 'CENTRE DES SERVICES FISCAUX DE SAINT LOUIS'),
	(6, 'CENTRE DES SERVICES FISCAUX DE MATAM'),
	(7, 'CENTRE DES SERVICES FISCAUX DE GRAND DAKAR'),
	(8, 'CENTRE DES SERVICES FISCAUX DE KAOLACK'),
	(9, 'CENTRE DES SERVICES FISCAUX DE KOLDA'),
	(10, 'CENTRE DES SERVICES FISCAUX DE PIKINE'),
	(11, 'CENTRE DES SERVICES FISCAUX DE RUFISQUE'),
	(12, 'CENTRE DES SERVICES FISCAUX DE FATICK'),
	(13, 'CENTRE DES SERVICES FISCAUX DIOURBEL'),
	(14, 'CENTRE DES SERVICES FISCAUX DE TAMBACOUNDA'),
	(15, 'CENTRE DES SERVICES FISCAUX DE MBOUR'),
	(16, 'CENTRE DES SERVICES FISCAUX DES PARCELLES ASSAINIES'),
	(17, 'CME 1- CENTRE DES MOYENNES ENTREPRISES DAKAR 1 '),
	(18, 'DIRECTION DES GRANDES ENTREPRISES (DGE)'),
	(19, 'CME 2- CENTRE DES MOYENNES ENTREPRISES DAKAR 2 '),
	(20, 'CENTRE DES PROFESSIONS REGLEMENGEES (CPR)'),
	(21, 'CENTRE DES SERVICES FISCAUX DE NGOR ALMADIES'),
	(22, 'CENTRE DES SERVICES FISCAUX DE SEDHIOU'),
	(23, 'CENTRE DES SERVICES FISCAUX DE KEDOUGOU'),
	(24, 'CENTRE DES SERVICES FISCAUX DE KAFFRINE'),
	(25, 'CENTRE DES SERVICES FISCAUX DAKAR-LIBERTE'),
	(26, 'CENTRE DES SERVICES FISCAUX DE GUEDIAWAYE');
/*!40000 ALTER TABLE `tp_centre_service_fiscal` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_fonction
CREATE TABLE IF NOT EXISTS `tp_fonction` (
  `fon_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fon_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fon_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_fonction : 4 rows
/*!40000 ALTER TABLE `tp_fonction` DISABLE KEYS */;
INSERT INTO `tp_fonction` (`fon_id`, `fon_libelle`) VALUES
	(1, 'Gérant'),
	(2, 'Directeur Général'),
	(3, 'Président Directeur Général'),
	(4, 'Administrateur Général');
/*!40000 ALTER TABLE `tp_fonction` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_forme_juridique
CREATE TABLE IF NOT EXISTS `tp_forme_juridique` (
  `foj_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `foj_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`foj_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_forme_juridique : 10 rows
/*!40000 ALTER TABLE `tp_forme_juridique` DISABLE KEYS */;
INSERT INTO `tp_forme_juridique` (`foj_id`, `foj_libelle`) VALUES
	(1, 'Société Unipersonnelle à responsabilité limitée (SURL)'),
	(2, 'Socièté anonyme unipersonnelle (SUA)'),
	(3, 'Socièté civile (CS)'),
	(4, 'Société par actions simplifiées (SAS)'),
	(5, 'Société anonyme (SA)'),
	(6, 'Société en Nom Collectif (SNC)'),
	(7, 'Société en Commandite Simple (SCS)'),
	(8, 'Groupement d’Intérêt Economique(GIE)'),
	(9, 'Société à Responsabilité Limitée (SARL)'),
	(10, 'Entreprise individuelle');
/*!40000 ALTER TABLE `tp_forme_juridique` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_localite
CREATE TABLE IF NOT EXISTS `tp_localite` (
  `loc_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `loc_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`loc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_localite : 45 rows
/*!40000 ALTER TABLE `tp_localite` DISABLE KEYS */;
INSERT INTO `tp_localite` (`loc_id`, `loc_libelle`) VALUES
	(1, 'Tambacounda'),
	(2, 'Goudomp'),
	(3, 'Bounkiling'),
	(4, 'Sédhiou'),
	(5, 'Saraya'),
	(6, 'Salemata'),
	(7, 'Kédougou'),
	(8, 'Koungheul'),
	(9, 'Malem-Hodar'),
	(10, 'Birkilane'),
	(11, 'Kaffrine'),
	(12, 'Oussouye'),
	(13, 'Bignogna'),
	(14, 'Ziguinchor'),
	(15, 'Tivaouane'),
	(16, 'M\'bour'),
	(17, 'Thiès'),
	(18, 'Goudiry'),
	(19, 'Koumpentoum'),
	(20, 'Bakel'),
	(21, 'Podor'),
	(22, 'Dagana'),
	(23, 'Saint-Louis'),
	(24, 'Ranérou'),
	(25, 'Kanel'),
	(26, 'Matam'),
	(27, 'Louga'),
	(28, 'Linguère'),
	(29, 'Kébémer'),
	(30, 'Médina Yoro Foulah'),
	(31, 'Vélingara'),
	(32, 'Kolda'),
	(33, 'Nioro du Rip'),
	(34, 'Guinguinéo'),
	(35, 'Kaolack'),
	(36, 'Gossas'),
	(37, 'Foundiougne'),
	(38, 'Fatick'),
	(39, 'Mbacké'),
	(40, 'Diourbel'),
	(41, 'Bambey'),
	(42, 'Rufisque'),
	(43, 'Guédiawaye'),
	(44, 'Pikine'),
	(45, 'Dakar');
/*!40000 ALTER TABLE `tp_localite` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_menu_item
CREATE TABLE IF NOT EXISTS `tp_menu_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `parent_id` bigint(20) NOT NULL,
  `priorite` bigint(20) NOT NULL,
  `profil` bigint(20) DEFAULT NULL,
  `route` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_menu_item : 64 rows
/*!40000 ALTER TABLE `tp_menu_item` DISABLE KEYS */;
INSERT INTO `tp_menu_item` (`id`, `code`, `icon`, `libelle`, `parent_id`, `priorite`, `profil`, `route`) VALUES
	(1, 'AD', NULL, 'Paramétrage', 0, 1, 1, '#'),
	(2, 'AD', NULL, 'Barême du Cout Visa', 1, 1, 1, 'list-bareme-visa'),
	(3, 'AD', NULL, 'Activités Principales', 1, 2, 1, 'list-activite-principale'),
	(4, 'AD', NULL, 'Gestion des inscriptions', 0, 2, 1, '#'),
	(5, 'AD', NULL, 'Validées', 4, 1, 1, 'list-inscription'),
	(6, 'AD', NULL, 'Gestion des cabinets', 0, 3, 1, '#'),
	(7, 'AD', NULL, 'Intervenants cabinets', 6, 3, 1, 'intervenant-cabinet'),
	(8, 'AD', NULL, 'Liste des agents', 24, 4, 1, 'list-agent'),
	(12, 'DE', NULL, 'Soumettre une demande', 11, 1, 5, 'depot/nouveau'),
	(10, 'AD', NULL, 'Attestation Visa', 0, 3, 1, '#'),
	(11, 'DE', NULL, 'Attestation Visa', 0, 1, 5, '#'),
	(13, 'DE', NULL, 'Mes Demandes', 11, 2, 5, 'depot/list'),
	(14, 'CA', NULL, 'Attestation Visa', 0, 1, 2, '#'),
	(15, 'CA', NULL, 'Demandes reçues', 14, 1, 2, 'demandes/recus'),
	(16, 'CA', NULL, 'Soumetre une demande', 14, 2, 2, 'demandes/cabinet'),
	(17, 'CA', NULL, 'Demande en brouillon', 14, 3, 2, 'cab-demande/brouillon'),
	(18, 'EX', NULL, 'Attestation Visa', 0, 1, 3, '#'),
	(19, 'EX', NULL, 'Demandes reçues', 18, 1, 3, 'demandes/recus'),
	(20, 'EX', NULL, 'Soumettre une demande', 18, 2, 3, 'demandes/cabinet'),
	(21, 'EX', NULL, 'Demande en brouillon', 18, 3, 3, 'cab-demande/brouillon'),
	(22, 'AD', NULL, 'Ajouter un cabinet', 6, 1, 1, 'add-cabinet'),
	(23, 'AD', NULL, 'Liste des cabinets', 6, 2, 1, 'list-cabinet'),
	(24, 'AD', NULL, 'Agents ODS', 0, 1, 1, '#'),
	(25, 'AD', NULL, 'Ajouter  un agent', 24, 1, 1, 'ajout-agent'),
	(27, 'AD', NULL, 'Demandes reçues', 10, 1, 1, 'demandes/recus/admin'),
	(52, 'AD', NULL, 'Nombre de visa par cabinet', 51, 1, 1, 'rapport-visa-cabinet'),
	(33, 'AF', NULL, 'Attestation Visa', 0, 1, 6, '#'),
	(34, 'AF', NULL, 'Demandes Visées', 33, 1, 6, '#'),
	(35, 'DE', NULL, 'Inscriptions', 0, 1, 5, '#'),
	(36, 'DE', NULL, 'Fiches d\'identification', 35, 1, 5, 'edit-inscription'),
	(37, 'DE', NULL, 'Intervenants', 35, 2, 5, 'list-intervenants-inscription'),
	(38, 'EX', NULL, 'Mon Cabinet', 0, 1, 3, '#'),
	(39, 'EX', NULL, 'Mes Clients', 0, 1, 3, '#'),
	(40, 'EX', NULL, 'Barême du Cout Visa', 18, 4, 3, 'list-bareme-visa'),
	(41, 'EX', NULL, 'Fiche d\'identification', 38, 1, 3, 'detail-cabinet-intervenant'),
	(42, 'EX', NULL, 'Intervenants', 38, 2, 3, 'list-intervenant-cabinet'),
	(43, 'EX', NULL, 'Inscrire un client', 39, 1, 3, 'inscription-client'),
	(44, 'EX', NULL, 'Clients', 39, 2, 3, 'list-client'),
	(45, 'CA', NULL, 'Mon cabinet', 0, 1, 2, '#'),
	(46, 'CA', NULL, 'Mes Clients', 0, 1, 2, '#'),
	(47, 'CA', NULL, 'Fiche d\'identification', 45, 1, 2, '#'),
	(48, 'CA', NULL, 'Intervenants', 45, 2, 2, '#'),
	(49, 'CA', NULL, ' Inscrire un client', 46, 1, 2, 'inscription-client'),
	(50, 'CA', NULL, 'Clients', 46, 2, 2, 'list-client'),
	(51, 'AD', NULL, 'Rapports', 0, 7, 1, '#'),
	(53, 'AD', NULL, 'Nombre de rejet par cabinet', 51, 2, 1, 'rapport-rejet-cabinet'),
	(54, 'SEL', NULL, 'Cabinet EC', 0, 1, 7, '#'),
	(55, 'SEL', NULL, 'Gestion des inscriptions', 0, 1, 7, '#'),
	(56, 'SEL', NULL, 'Liste des cabinets', 54, 1, 7, 'list-abonnement-cabinet'),
	(57, 'SEL', NULL, 'Intervenant cabinet', 54, 2, 7, 'intervenant-abonnement-cabinet'),
	(58, 'SEL', NULL, 'Entreprise', 55, 1, 7, 'list-abonnement-inscription'),
	(59, 'SUP', NULL, 'Attestation Visa', 0, 1, 4, '#'),
	(60, 'SUP', NULL, 'Demandes reçues', 59, 1, 4, 'demandes/recus'),
	(61, 'SUP', NULL, 'Barême du Cout Visa', 59, 4, 4, 'list-bareme-visa'),
	(62, 'SUP', NULL, 'Mon Cabinet', 0, 1, 4, '#'),
	(63, 'SUP', NULL, 'Fiche d\'identification', 62, 1, 4, 'detail-cabinet-intervenant'),
	(64, 'SUP', NULL, 'Intervenants', 62, 2, 4, 'list-intervenant-cabinet'),
	(65, 'SUP', NULL, 'Mes Clients', 0, 1, 4, '#'),
	(66, 'SUP', NULL, 'Inscrire un client', 65, 1, 4, 'inscription-client'),
	(67, 'SUP', NULL, 'Clients', 65, 2, 4, 'list-client'),
	(68, 'SEL', NULL, 'Intervenant contribuable', 55, 1, 7, 'intervenant-abonnement-contribuable'),
	(70, 'CA', NULL, 'Eta LINK', 0, 5, 2, 'etalink/list'),
	(69, 'DE', NULL, 'Eta LINK', 0, 5, 5, 'etalink/list'),
	(71, 'EX', NULL, 'Eta LINK', 0, 5, 3, 'etalink/list');
/*!40000 ALTER TABLE `tp_menu_item` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_nature_fichier
CREATE TABLE IF NOT EXISTS `tp_nature_fichier` (
  `naf_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `naf_extension` varchar(255) DEFAULT NULL,
  `naf_icone` varchar(255) DEFAULT NULL,
  `naf_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`naf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_nature_fichier : 8 rows
/*!40000 ALTER TABLE `tp_nature_fichier` DISABLE KEYS */;
INSERT INTO `tp_nature_fichier` (`naf_id`, `naf_extension`, `naf_icone`, `naf_libelle`) VALUES
	(1, 'pdf', 'picture_as_pdf', 'Visa'),
	(2, 'pdf', 'picture_as_pdf', 'EFPDF'),
	(3, 'xlsx', 'insert_drive_file', 'EFExcel'),
	(4, 'pdf', 'picture_as_pdf', 'Autres'),
	(5, 'xlsx', 'insert_drive_file', 'EFExcelSigné'),
	(15, 'xlsm', NULL, 'EtaLink'),
	(16, 'xlsm', NULL, 'FEtalink'),
	(17, 'xlsx', NULL, 'GEtalink');
/*!40000 ALTER TABLE `tp_nature_fichier` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_profil
CREATE TABLE IF NOT EXISTS `tp_profil` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `domaine` varchar(255) DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_profil : 9 rows
/*!40000 ALTER TABLE `tp_profil` DISABLE KEYS */;
INSERT INTO `tp_profil` (`id`, `code`, `domaine`, `nom`) VALUES
	(1, 'AD', '', 'Admin'),
	(2, 'CA', '', 'Comptable Agréé'),
	(3, 'EX', '', 'Expert Comptable'),
	(4, 'SUP', '', 'Superviseur'),
	(5, 'DE', '', 'Responsable'),
	(6, 'AF', '', 'Agent du Fisc'),
	(7, 'SEL', NULL, 'Support Etat Link'),
	(8, 'ASR', NULL, 'Assistant responsable'),
	(9, 'ASS', NULL, 'Assistant ');
/*!40000 ALTER TABLE `tp_profil` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_qualite_signature
CREATE TABLE IF NOT EXISTS `tp_qualite_signature` (
  `qsi_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `qsi_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`qsi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Listage des données de la table bd_orbusLink_visa.tp_qualite_signature : 2 rows
/*!40000 ALTER TABLE `tp_qualite_signature` DISABLE KEYS */;
INSERT INTO `tp_qualite_signature` (`qsi_id`, `qsi_libelle`) VALUES
	(1, 'Entité uniquement'),
	(2, 'Entité et Personne physique');
/*!40000 ALTER TABLE `tp_qualite_signature` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_regime_imposition
CREATE TABLE IF NOT EXISTS `tp_regime_imposition` (
  `rei_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rei_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rei_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_regime_imposition : 3 rows
/*!40000 ALTER TABLE `tp_regime_imposition` DISABLE KEYS */;
INSERT INTO `tp_regime_imposition` (`rei_id`, `rei_libelle`) VALUES
	(1, ' Réel normal'),
	(2, ' Réel simplifié'),
	(3, 'CGU');
/*!40000 ALTER TABLE `tp_regime_imposition` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_systeme_comptable
CREATE TABLE IF NOT EXISTS `tp_systeme_comptable` (
  `syc_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `syc_description` longtext,
  `syc_libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`syc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_systeme_comptable : 4 rows
/*!40000 ALTER TABLE `tp_systeme_comptable` DISABLE KEYS */;
INSERT INTO `tp_systeme_comptable` (`syc_id`, `syc_description`, `syc_libelle`) VALUES
	(1, '', 'Système normal'),
	(2, 'Vous avez choisi le système minimal de trésorerie (SMT).! Ce cadre comptable concerne les contribuables avec un C.A inférieur ou égal à : !• 60 Millions pour les entreprises de négoce !• 40 Millions pour les entreprises industrielles !• 30 Millions pour les entreprises de services.', 'Système minimal de trésorerie'),
	(3, 'Vous avez choisi le cadre comptable bancaire. !Ce dernier est réservé exclusivement aux banques et établissements financiers. !Suivant l’article 31 du CGI, au moment du dépôt, vous devez en tant que banque ou établissement financier,  en plus des états financiers, joindre les documents ci-après : !• COMPTE AMORTISSEMENT !• COMPTE PROVISIONS  !• RAPPORTS !• RELEVE DETAILLE DES FRAIS GENERAUX !• COPIE ANNUELLE SUR L’EXPLOITATION.', 'Banque et établissements financiers'),
	(4, 'Vous avez choisi le cadre comptable CIMA. !Ce dernier est réservé exclusivement aux sociétés d’assurances et de réassurances. !Suivant l’article 31 du CGI, au moment du dépôt, vous devez en tant que Assurances,  en plus des états financiers, joindre les documents ci-après :!• Tableaux annexés  !• Compte rendu détaillé.', 'Assurances');
/*!40000 ALTER TABLE `tp_systeme_comptable` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_type_entite
CREATE TABLE IF NOT EXISTS `tp_type_entite` (
  `tye_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tye_libelle` varchar(255) DEFAULT NULL,
  `tye_limite` float DEFAULT NULL,
  PRIMARY KEY (`tye_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_type_entite : 2 rows
/*!40000 ALTER TABLE `tp_type_entite` DISABLE KEYS */;
INSERT INTO `tp_type_entite` (`tye_id`, `tye_libelle`, `tye_limite`) VALUES
	(1, 'Personne physique', 60000000),
	(2, 'Personne morale ', 40000000);
/*!40000 ALTER TABLE `tp_type_entite` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tp_type_structure
CREATE TABLE IF NOT EXISTS `tp_type_structure` (
  `tys_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tys_description` longtext,
  `tys_libelle` varchar(255) DEFAULT NULL,
  `tys_seuil` float DEFAULT NULL,
  PRIMARY KEY (`tys_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tp_type_structure : 3 rows
/*!40000 ALTER TABLE `tp_type_structure` DISABLE KEYS */;
INSERT INTO `tp_type_structure` (`tys_id`, `tys_description`, `tys_libelle`, `tys_seuil`) VALUES
	(1, 'Vous avez choisi le système minimal de trésorerie (SMT). Ce cadre comptable concerne les contribuables avec un C.A inférieur ou égal à:', 'Négoce', 60000000),
	(2, 'Vous avez choisi le cadre comptable bancaire. Ce dernier est réservé exclusivement aux banques et établissements financiers.', 'Industrielle', 40000000),
	(3, 'Vous avez choisi le cadre comptable CIMA. Ce dernier est réservé exclusivement aux sociétés d’assurances et de réassurances.', 'Service', 30000000);
/*!40000 ALTER TABLE `tp_type_structure` ENABLE KEYS */;

-- Listage de la structure de la table bd_orbusLink_visa. tr_centre_service_fiscal_localite
CREATE TABLE IF NOT EXISTS `tr_centre_service_fiscal_localite` (
  `id_centre_service_fiscal` bigint(20) NOT NULL,
  `id_localite` bigint(20) NOT NULL,
  PRIMARY KEY (`id_centre_service_fiscal`,`id_localite`),
  KEY `FKaenrkrft066gdni8of5p339w4` (`id_localite`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Listage des données de la table bd_orbusLink_visa.tr_centre_service_fiscal_localite : 97 rows
/*!40000 ALTER TABLE `tr_centre_service_fiscal_localite` DISABLE KEYS */;
INSERT INTO `tr_centre_service_fiscal_localite` (`id_centre_service_fiscal`, `id_localite`) VALUES
	(1, 45),
	(2, 27),
	(2, 28),
	(2, 29),
	(3, 15),
	(3, 17),
	(4, 12),
	(4, 13),
	(4, 14),
	(5, 21),
	(5, 22),
	(5, 23),
	(6, 24),
	(6, 25),
	(6, 26),
	(7, 45),
	(8, 33),
	(8, 34),
	(8, 35),
	(9, 30),
	(9, 31),
	(9, 32),
	(10, 44),
	(11, 42),
	(12, 36),
	(12, 37),
	(12, 38),
	(13, 39),
	(13, 40),
	(13, 41),
	(14, 1),
	(14, 18),
	(14, 19),
	(14, 20),
	(15, 16),
	(16, 45),
	(17, 45),
	(18, 1),
	(18, 2),
	(18, 3),
	(18, 4),
	(18, 5),
	(18, 6),
	(18, 7),
	(18, 8),
	(18, 9),
	(18, 10),
	(18, 11),
	(18, 12),
	(18, 13),
	(18, 14),
	(18, 15),
	(18, 16),
	(18, 17),
	(18, 18),
	(18, 19),
	(18, 20),
	(18, 21),
	(18, 22),
	(18, 23),
	(18, 24),
	(18, 25),
	(18, 26),
	(18, 27),
	(18, 28),
	(18, 29),
	(18, 30),
	(18, 31),
	(18, 32),
	(18, 33),
	(18, 34),
	(18, 35),
	(18, 36),
	(18, 37),
	(18, 38),
	(18, 39),
	(18, 40),
	(18, 41),
	(18, 42),
	(18, 43),
	(18, 44),
	(18, 45),
	(19, 45),
	(20, 45),
	(21, 45),
	(22, 2),
	(22, 3),
	(22, 4),
	(23, 5),
	(23, 6),
	(23, 7),
	(24, 8),
	(24, 9),
	(24, 10),
	(24, 11),
	(25, 45),
	(26, 43);
/*!40000 ALTER TABLE `tr_centre_service_fiscal_localite` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
